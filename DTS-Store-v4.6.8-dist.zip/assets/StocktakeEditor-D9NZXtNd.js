import{j as s}from"./ui-vendor-Dmwbbbfi.js";import{i as G,u as K,r as _}from"./react-vendor-BTZHR6BZ.js";import{a as R,b as V,s as J}from"./index-BCQvBTPv.js";import{W as Q}from"./WmsCard-DIsBrz-x.js";import{W as M}from"./WmsBadge-B-6OdpqF.js";import{W as b}from"./WmsButton-9xxmv3Hd.js";import{W as C,b as j,a as A,c as X}from"./WmsField-j5pBbvGU.js";import{e as n,w as Y}from"./print-DK2iyTys.js";import"./icons-Cc2ZhWP9.js";import"./supabase-fIMjPNmZ.js";function Z(l,k,t,h){const f=h==="ar"?"rtl":"ltr",w=h==="ar"?"'Segoe UI Arabic','Segoe UI',Tahoma,Arial,sans-serif":"'Inter','Segoe UI',system-ui,sans-serif",i=new Date().toLocaleString("en-GB"),v=m=>{try{return new Date(m).toLocaleDateString("en-GB")}catch{return m}},u=k.reduce((m,g)=>m+((g.counted_qty??0)-g.expected_qty),0),x=k.map(m=>{const g=(m.counted_qty??0)-m.expected_qty,$=g===0?"":g>0?"pos":"neg";return`<tr>
      <td class="num">${n(m.line_no)}</td>
      <td class="mono">${n(m.part_no)}</td>
      <td>${n(m.description)}</td>
      <td class="num">${n(m.unit??"—")}</td>
      <td class="num">${n(m.expected_qty)}</td>
      <td class="num">${m.counted_qty==null?"____":n(m.counted_qty)}</td>
      <td class="num ${$}">${m.counted_qty==null?"":n(g)}</td>
      <td>${n(m.remarks??"")}</td>
    </tr>`}).join("");return`<!doctype html>
<html lang="${h}" dir="${f}">
<head>
<meta charset="utf-8" />
<title>${n(l.title)} — ${n(l.count_no)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:${w};color:#111;margin:0;padding:14mm;font-size:10pt}
  .brand{display:flex;justify-content:space-between;align-items:flex-end;
    border-bottom:2px solid #1A1F2C;padding-bottom:3mm;margin-bottom:5mm}
  .b-name{font-weight:700;font-size:13pt;color:#1A1F2C}
  h1{margin:0 0 1mm;font-size:16pt;color:#1A1F2C}
  .doc-no{font-family:ui-monospace,Menlo,monospace;font-size:11pt;color:#0d4ed8}
  .meta{display:grid;grid-template-columns:repeat(4,1fr);gap:2mm 4mm;margin-bottom:4mm}
  .meta .k{color:#666;font-size:8pt;text-transform:uppercase;letter-spacing:.5px}
  .meta .v{font-weight:600;color:#111;margin-top:.5mm;font-size:10pt}
  table{width:100%;border-collapse:collapse;font-size:9pt;margin-bottom:4mm}
  thead th{background:#1A1F2C;color:#FFD700;text-align:start;padding:2.5mm;
    font-size:8.5pt;text-transform:uppercase;letter-spacing:.4px}
  tbody td{padding:2mm;border-bottom:1px solid #ddd;vertical-align:middle}
  tbody tr:nth-child(even) td{background:#fafafa}
  .num{text-align:center;font-family:ui-monospace,Menlo,monospace}
  .mono{font-family:ui-monospace,Menlo,monospace;color:#0d4ed8}
  .pos{color:#15803d;font-weight:600}
  .neg{color:#b91c1c;font-weight:600}
  .totals{display:flex;justify-content:space-between;gap:6mm;
    background:#f5f5f5;border:1px solid #ddd;padding:3mm;border-radius:2mm;margin-bottom:5mm}
  .totals span{font-size:9pt;color:#333}
  .totals b{font-family:ui-monospace,Menlo,monospace;color:#1A1F2C}
  .notes-block{border:1px solid #ccc;border-radius:2mm;padding:3mm;font-size:9pt;color:#333;min-height:12mm;margin-bottom:6mm}
  .sig{display:grid;grid-template-columns:1fr 1fr;gap:10mm;margin-top:10mm}
  .sig .box{border-top:1px solid #333;padding-top:2mm;text-align:center;font-size:9pt;color:#555}
  .footer{margin-top:6mm;font-size:8pt;color:#888;text-align:center}
  @page{size:A4;margin:0}
</style>
</head>
<body>
  <div class="brand">
    <div><h1>${n(l.title)}</h1><div class="doc-no">${n(t.doc_no)}: ${n(l.count_no)}</div></div>
    <div class="b-name">${n(t.brand)}</div>
  </div>
  <div class="meta">
    <div><div class="k">${n(t.date)}</div><div class="v">${n(v(l.count_date))}</div></div>
    <div><div class="k">${n(t.warehouse)}</div><div class="v">${n(l.warehouse)}</div></div>
    <div><div class="k">${n(t.status)}</div><div class="v">${n(l.status)}</div></div>
    <div><div class="k">${n(t.totals_lines)}</div><div class="v">${n(k.length)}</div></div>
  </div>
  <table>
    <thead><tr>
      <th style="width:6%">${n(t.line)}</th>
      <th style="width:14%">${n(t.part_no)}</th>
      <th>${n(t.description)}</th>
      <th style="width:8%">${n(t.unit)}</th>
      <th style="width:10%">${n(t.expected)}</th>
      <th style="width:10%">${n(t.counted)}</th>
      <th style="width:10%">${n(t.variance)}</th>
      <th style="width:18%">${n(t.remarks)}</th>
    </tr></thead>
    <tbody>${x||'<tr><td colspan="8" style="text-align:center;color:#999;padding:8mm">—</td></tr>'}</tbody>
  </table>
  <div class="totals">
    <span>${n(t.totals_lines)}: <b>${n(k.length)}</b></span>
    <span>${n(t.totals_variance)}: <b class="${u===0?"":u>0?"pos":"neg"}">${n(u)}</b></span>
  </div>
  ${l.notes?`<div class="notes-block"><strong>${n(t.notes)}:</strong> ${n(l.notes)}</div>`:""}
  <div class="sig">
    <div class="box">${n(t.signature_counted)}</div>
    <div class="box">${n(t.signature_verified)}</div>
  </div>
  <div class="footer">${n(t.printed_at)}: ${n(i)}</div>
</body></html>`}const F=l=>({line_no:l,item_id:"",location_id:null,expected_qty:0,counted_qty:0,remarks:""});function mt(){const{id:l}=G(),k=K(),{t,language:h}=R(),{toast:f}=V(),w=!l||l==="new",[i,v]=_.useState({count_no:"",count_date:new Date().toISOString().slice(0,10),warehouse_id:"",status:"draft",notes:""}),[u,x]=_.useState([]),[m,g]=_.useState([]),[$,I]=_.useState([]),[N,q]=_.useState(!1),p=J;_.useEffect(()=>{let e=!1;return(async()=>{const c=await p.from("warehouses").select("id,code,name_ar,name_en").order("code",{ascending:!0}),r=await p.from("items_master").select("id,part_no,description,default_unit,name_ar,name_en").order("part_no",{ascending:!0});e||(g(c.data??[]),I(r.data??[]))})(),()=>{e=!0}},[p]),_.useEffect(()=>{if(w||!l)return;let e=!1;return(async()=>{const c=await p.from("stock_counts").select("id,count_no,count_date,warehouse_id,status,notes").eq("id",l),r=await p.from("stock_count_lines").select("id,line_no,item_id,location_id,expected_qty,counted_qty,remarks").eq("count_id",l);if(e)return;const a=c.data?.[0];a&&v({...a,notes:a.notes??""});const d=(r.data??[]).map(o=>({...o,remarks:o.remarks??""})).sort((o,y)=>o.line_no-y.line_no);x(d)})(),()=>{e=!0}},[l,w,p]);const D=_.useMemo(()=>new Map($.map(e=>[e.id,e])),[$]),E=_.useCallback(e=>{const c=(h==="ar"?e.name_ar:e.name_en)||e.description;return`${e.part_no} — ${c}`},[h]),T=_.useCallback(async()=>{if(!i.warehouse_id){f({title:t("wms.stocktake.err-pick-wh"),variant:"destructive"});return}q(!0);try{const c=(await p.from("inv_stock").select("item_id,location_id,qty").eq("warehouse_id",i.warehouse_id)).data??[],r=new Map;u.forEach(o=>r.set(`${o.item_id}|${o.location_id??""}`,o));let a=1;const d=c.map(o=>{const y=`${o.item_id}|${o.location_id??""}`,W=r.get(y);return{...W??F(a),line_no:a++,item_id:o.item_id,location_id:o.location_id,expected_qty:Number(o.qty||0),counted_qty:W?.counted_qty??0,remarks:W?.remarks??""}});x(d),f({title:t("wms.stocktake.toast-synced")})}finally{q(!1)}},[i.warehouse_id,u,p,t,f]),S=(e,c)=>x(r=>r.map((a,d)=>d===e?{...a,...c}:a)),B=()=>x(e=>[...e,F(e.length+1)]),H=e=>x(c=>c.filter((r,a)=>a!==e).map((r,a)=>({...r,line_no:a+1}))),z=_.useMemo(()=>{const e=u.reduce((c,r)=>c+(Number(r.counted_qty||0)-Number(r.expected_qty||0)),0);return{lines:u.length,variance:e}},[u]),O=()=>i.count_no.trim()?i.warehouse_id?u.length?u.some(e=>!e.item_id)?t("wms.stocktake.err-item"):null:t("wms.stocktake.err-lines"):t("wms.stocktake.err-pick-wh"):t("wms.stocktake.err-no"),L=_.useCallback(async e=>{const c=O();if(c)return f({title:c,variant:"destructive"}),null;q(!0);try{const r={count_no:i.count_no.trim(),count_date:i.count_date,warehouse_id:i.warehouse_id,status:e,notes:i.notes||null,...e==="posted"?{posted_at:new Date().toISOString()}:{}};let a=i.id;if(w||!a){const{data:o,error:y}=await p.from("stock_counts").insert(r).select().single();if(y||!o)throw y??new Error("insert failed");a=o.id}else{const{error:o}=await p.from("stock_counts").update(r).eq("id",a);if(o)throw o;await p.from("stock_count_lines").delete().eq("count_id",a)}const d=u.filter(o=>o.item_id).map(o=>({count_id:a,line_no:o.line_no,item_id:o.item_id,location_id:o.location_id,expected_qty:Number(o.expected_qty||0),counted_qty:Number(o.counted_qty||0),remarks:o.remarks||null}));if(d.length){const{error:o}=await p.from("stock_count_lines").insert(d).select().single();o&&console.warn(o)}return f({title:t(e==="posted"?"wms.stocktake.toast-posted":"wms.form.toast-saved")}),v(o=>({...o,id:a,status:e})),a??null}catch(r){return console.error(r),f({title:t("wms.form.toast-error"),variant:"destructive"}),null}finally{q(!1)}},[i,u,w,p,t,f]),P=()=>{const e=m.find(a=>a.id===i.warehouse_id),c=e?`${e.code} · ${h==="ar"?e.name_ar:e.name_en||e.name_ar}`:"—",r=Z({title:t("wms.nav.stocktake"),count_no:i.count_no||"—",count_date:i.count_date,warehouse:c,status:t(`wms.status.${i.status}`),notes:i.notes},u.filter(a=>a.item_id).map(a=>{const d=D.get(a.item_id);return{line_no:a.line_no,part_no:d?.part_no??"—",description:d?(h==="ar"?d.name_ar:d.name_en)||d.description:"—",unit:d?.default_unit,expected_qty:a.expected_qty,counted_qty:a.counted_qty,remarks:a.remarks}}),{brand:t("wms.brand.name"),doc_no:t("wms.col.txn-no"),date:t("wms.col.date"),warehouse:t("wms.nav.warehouses"),status:t("wms.col.status"),notes:t("wms.form.notes"),line:t("wms.col.line"),part_no:t("wms.col.part-no"),description:t("wms.col.name"),unit:t("wms.col.unit"),expected:t("wms.stocktake.expected"),counted:t("wms.stocktake.counted"),variance:t("wms.stocktake.variance"),remarks:t("wms.form.notes"),signature_counted:t("wms.stocktake.signature-counted"),signature_verified:t("wms.stocktake.signature-verified"),totals_lines:t("wms.stocktake.total-lines"),totals_variance:t("wms.stocktake.total-variance"),printed_at:t("wms.form.printed-at")},h);Y(r,`${t("wms.nav.stocktake")} — ${i.count_no}`)},U=`${t("wms.nav.stocktake")} — ${w?t("wms.form.new"):i.count_no}`;return s.jsxs(Q,{title:U,subtitle:t(w?"wms.form.new-sub":"wms.form.edit-sub"),children:[s.jsxs("div",{className:"wms-form-grid",children:[s.jsx(C,{label:t("wms.col.txn-no"),children:s.jsx(j,{value:i.count_no,onChange:e=>v({...i,count_no:e.target.value})})}),s.jsx(C,{label:t("wms.col.date"),children:s.jsx(j,{type:"date",value:i.count_date,onChange:e=>v({...i,count_date:e.target.value})})}),s.jsx(C,{label:t("wms.nav.warehouses"),children:s.jsxs(A,{value:i.warehouse_id,onChange:e=>v({...i,warehouse_id:e.target.value}),children:[s.jsx("option",{value:"",children:"—"}),m.map(e=>s.jsxs("option",{value:e.id,children:[e.code," · ",h==="ar"?e.name_ar:e.name_en||e.name_ar]},e.id))]})})]}),s.jsxs("div",{className:"wms-lines-actions",children:[s.jsxs("span",{className:"wms-lines-title",children:[t("wms.form.lines")," · ",s.jsxs(M,{tone:z.variance===0?"green":z.variance>0?"blue":"red",children:[t("wms.stocktake.total-variance"),": ",z.variance]})]}),s.jsxs("div",{style:{display:"flex",gap:".5rem"},children:[s.jsxs(b,{size:"sm",variant:"ghost",onClick:T,disabled:N,children:["↻ ",t("wms.stocktake.sync-from-stock")]}),s.jsxs(b,{size:"sm",variant:"ghost",onClick:B,children:["+ ",t("wms.form.add-line")]})]})]}),s.jsx("div",{className:"wms-table-wrap",children:s.jsxs("table",{className:"wms-table is-edit",children:[s.jsx("thead",{children:s.jsxs("tr",{children:[s.jsx("th",{style:{width:50},children:t("wms.col.line")}),s.jsx("th",{children:t("wms.col.part-no")}),s.jsx("th",{style:{width:100},children:t("wms.stocktake.expected")}),s.jsx("th",{style:{width:100},children:t("wms.stocktake.counted")}),s.jsx("th",{style:{width:100},children:t("wms.stocktake.variance")}),s.jsx("th",{children:t("wms.form.notes")}),s.jsx("th",{style:{width:40}})]})}),s.jsxs("tbody",{children:[u.map((e,c)=>{const r=Number(e.counted_qty||0)-Number(e.expected_qty||0),a=r===0?"green":r>0?"blue":"red";return s.jsxs("tr",{children:[s.jsx("td",{className:"wms-td-mono",children:e.line_no}),s.jsx("td",{children:s.jsxs(A,{value:e.item_id,onChange:d=>S(c,{item_id:d.target.value}),children:[s.jsx("option",{value:"",children:"—"}),$.map(d=>s.jsx("option",{value:d.id,children:E(d)},d.id))]})}),s.jsx("td",{children:s.jsx(j,{type:"number",min:0,step:"any",value:e.expected_qty,readOnly:!0})}),s.jsx("td",{children:s.jsx(j,{type:"number",min:0,step:"any",value:e.counted_qty,onChange:d=>S(c,{counted_qty:Number(d.target.value)||0})})}),s.jsx("td",{children:s.jsx(M,{tone:a,children:r})}),s.jsx("td",{children:s.jsx(j,{value:e.remarks,onChange:d=>S(c,{remarks:d.target.value})})}),s.jsx("td",{children:s.jsx("button",{className:"wms-icon-btn",type:"button",onClick:()=>H(c),"aria-label":"delete",children:"×"})})]},c)}),u.length===0&&s.jsx("tr",{children:s.jsx("td",{colSpan:7,style:{textAlign:"center",color:"hsl(var(--wms-text3))",padding:"1.5rem"},children:t("wms.stocktake.empty-hint")})})]})]})}),s.jsx("div",{className:"wms-form-grid",style:{marginTop:"1rem"},children:s.jsx("div",{style:{gridColumn:"1 / -1"},children:s.jsx(C,{label:t("wms.form.notes"),children:s.jsx(X,{value:i.notes,onChange:e=>v({...i,notes:e.target.value})})})})}),s.jsxs("div",{className:"wms-form-footer",children:[s.jsx(b,{variant:"ghost",onClick:()=>k("/wms/stocktake"),children:t("wms.form.cancel")}),s.jsx(b,{variant:"ghost",onClick:P,children:t("wms.form.print")}),s.jsx(b,{variant:"ghost",disabled:N,onClick:()=>L("draft"),children:t("wms.form.save-draft")}),s.jsx(b,{variant:"primary",disabled:N,onClick:async()=>{const e=await L("posted");e&&w&&k(`/wms/stocktake/${e}`,{replace:!0})},children:t("wms.form.post")})]})]})}export{mt as default};
