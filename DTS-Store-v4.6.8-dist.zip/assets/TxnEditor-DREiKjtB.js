import{j as i}from"./ui-vendor-Dmwbbbfi.js";import{i as V,u as X,r as h}from"./react-vendor-BTZHR6BZ.js";import{a as Y,b as Z,s as ee}from"./index-BCQvBTPv.js";import{W as te}from"./WmsCard-DIsBrz-x.js";import{W as C}from"./WmsButton-9xxmv3Hd.js";import{W as x,b as y,a as F,c as ne}from"./WmsField-j5pBbvGU.js";import{e as t,w as M}from"./print-DK2iyTys.js";import"./icons-Cc2ZhWP9.js";import"./supabase-fIMjPNmZ.js";function ie(o,u,s,e){const _=e==="ar"?"rtl":"ltr",b=e==="ar"?"'Segoe UI Arabic','Segoe UI',Tahoma,Arial,sans-serif":"'Inter','Segoe UI',system-ui,sans-serif",c=new Date().toLocaleString("en-GB"),g=v=>{try{return new Date(v).toLocaleDateString("en-GB")}catch{return v}},r=u.map(v=>`
    <tr>
      <td class="num">${t(v.line_no)}</td>
      <td class="mono">${t(v.part_no??"—")}</td>
      <td>${t(v.description??"—")}</td>
      <td class="num">${t(v.qty)}</td>
      <td>${t(v.unit??"—")}</td>
      <td>${t(v.notes??"")}</td>
    </tr>`).join("");return`<!doctype html>
<html lang="${e}" dir="${_}">
<head>
<meta charset="utf-8" />
<title>${t(o.title)} — ${t(o.txn_no)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:${b};color:#111;margin:0;padding:18mm 14mm;font-size:12pt}
  h1{font-size:20pt;margin:0 0 4mm;color:#1A1F2C}
  .brand{display:flex;justify-content:space-between;align-items:center;
    border-bottom:2px solid #1A1F2C;padding-bottom:4mm;margin-bottom:6mm}
  .brand .b-name{font-weight:700;font-size:14pt;color:#1A1F2C}
  .brand .b-doc{font-family:ui-monospace,Menlo,monospace;font-size:11pt;color:#555}
  .meta{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm 6mm;margin-bottom:6mm;font-size:10pt}
  .meta .k{color:#666;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  .meta .v{font-weight:600;color:#111;margin-top:1mm}
  table{width:100%;border-collapse:collapse;margin-bottom:6mm;font-size:10pt}
  thead th{background:#1A1F2C;color:#FFD700;text-align:start;padding:3mm 2mm;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  tbody td{padding:2.5mm;border-bottom:1px solid #ddd;vertical-align:top}
  .num{text-align:center;font-family:ui-monospace,Menlo,monospace}
  .mono{font-family:ui-monospace,Menlo,monospace;color:#0d4ed8}
  .notes-block{border:1px solid #ccc;border-radius:3px;padding:3mm;margin-top:4mm;font-size:10pt;color:#333;min-height:14mm}
  .sig{display:grid;grid-template-columns:1fr 1fr;gap:10mm;margin-top:14mm}
  .sig .box{border-top:1px solid #333;padding-top:2mm;text-align:center;font-size:9pt;color:#555}
  .footer{margin-top:8mm;font-size:8pt;color:#888;text-align:center}
  @page{size:A4;margin:0}
</style>
</head>
<body>
  <div class="brand">
    <div class="b-name">${t(s.brand)}</div>
    <div class="b-doc">${t(s.doc_no)}: ${t(o.txn_no)}</div>
  </div>
  <h1>${t(o.title)}</h1>
  <div class="meta">
    <div><div class="k">${t(s.date)}</div><div class="v">${t(g(o.txn_date))}</div></div>
    <div><div class="k">${t(s.party)}</div><div class="v">${t(o.party_name??"—")}</div></div>
    <div><div class="k">${t(s.reference)}</div><div class="v">${t(o.reference??"—")}</div></div>
    <div><div class="k">${t(s.status)}</div><div class="v">${t(o.status??"—")}</div></div>
    <div><div class="k">${t(s.from)}</div><div class="v">${t(o.from_warehouse??"—")}</div></div>
    <div><div class="k">${t(s.to)}</div><div class="v">${t(o.to_warehouse??"—")}</div></div>
  </div>
  <table>
    <thead><tr>
      <th style="width:8%">${t(s.line)}</th>
      <th style="width:18%">${t(s.part_no)}</th>
      <th>${t(s.description)}</th>
      <th style="width:10%">${t(s.qty)}</th>
      <th style="width:10%">${t(s.unit)}</th>
      <th style="width:22%">${t(s.notes)}</th>
    </tr></thead>
    <tbody>${r||'<tr><td colspan="6" style="text-align:center;color:#999;padding:8mm">—</td></tr>'}</tbody>
  </table>
  ${o.notes?`<div class="notes-block"><strong>${t(s.notes)}:</strong> ${t(o.notes)}</div>`:""}
  ${o.recipient_name||o.recipient_title||o.recipient_empno||o.receipt_time||o.is_delegated?`
  <div class="notes-block">
    <strong>${t(s.recipient_info??"Recipient")}:</strong>
    <div class="meta" style="margin-top:3mm">
      <div><div class="k">${t(s.recipient_name??"Name")}</div><div class="v">${t(o.recipient_name??"—")}</div></div>
      <div><div class="k">${t(s.recipient_title??"Title")}</div><div class="v">${t(o.recipient_title??"—")}</div></div>
      <div><div class="k">${t(s.recipient_empno??"Emp #")}</div><div class="v">${t(o.recipient_empno??"—")}</div></div>
      <div><div class="k">${t(s.receipt_time??"Time")}</div><div class="v">${t(o.receipt_time??"—")}</div></div>
      ${o.is_delegated?`<div><div class="k">${t(s.delegation??"Delegation")}</div><div class="v">✓</div></div>`:""}
    </div>
  </div>`:""}
  <div class="sig">
    <div class="box">${t(s.signature)} 1</div>
    <div class="box">${t(s.signature)} 2</div>
  </div>
  <div class="footer">${t(s.printed_at)}: ${t(c)}</div>
</body></html>`}function se(o,u,s,e){const _=e==="ar"?"rtl":"ltr",b=e==="ar"?"'Segoe UI Arabic','Segoe UI',Tahoma,Arial,sans-serif":"'Inter','Segoe UI',system-ui,sans-serif",c=new Date().toLocaleString("en-GB"),g=d=>{try{return new Date(d).toLocaleDateString("en-GB")}catch{return d}},r=u.map(d=>`
    <tr>
      <td class="num">${t(d.line_no)}</td>
      <td class="mono">${t(d.part_no??"—")}</td>
      <td>${t(d.description??"—")}</td>
      <td class="num">${t(d.qty)}</td>
      <td>${t(d.unit??"—")}</td>
      <td>${t(d.notes??"")}</td>
    </tr>`).join(""),v=(d,$)=>`
    <div class="sig-box">
      <div class="sig-title">${t(d)}</div>
      <div class="sig-row"><span class="sig-k">${t(s.delivered_by_label??s.received_by_label??"")}</span><span class="sig-v">${t($??"")}</span></div>
      <div class="sig-row"><span class="sig-k">${t(s.date_label??s.date)}</span><span class="sig-v">${t(g(o.txn_date))}</span></div>
      <div class="sig-line"></div>
    </div>`;return`<!doctype html>
<html lang="${e}" dir="${_}">
<head>
<meta charset="utf-8" />
<title>${t(o.title)} — ${t(o.txn_no)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:${b};color:#111;margin:0;padding:18mm 14mm;font-size:12pt}
  h1{font-size:20pt;margin:0 0 4mm;color:#1A1F2C}
  .brand{display:flex;justify-content:space-between;align-items:center;
    border-bottom:2px solid #1A1F2C;padding-bottom:4mm;margin-bottom:6mm}
  .brand .b-name{font-weight:700;font-size:14pt;color:#1A1F2C}
  .brand .b-doc{font-family:ui-monospace,Menlo,monospace;font-size:11pt;color:#555}
  .meta{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm 6mm;margin-bottom:6mm;font-size:10pt}
  .meta .k{color:#666;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  .meta .v{font-weight:600;color:#111;margin-top:1mm}
  .wh-strip{display:grid;grid-template-columns:1fr auto 1fr;gap:6mm;align-items:center;
    background:#fafafa;border:1px solid #1A1F2C;border-radius:4px;padding:4mm;margin-bottom:6mm}
  .wh-cell{font-size:11pt;color:#1A1F2C}
  .wh-cell .k{font-size:9pt;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:1mm}
  .wh-cell .v{font-weight:700;font-size:13pt}
  .wh-arrow{font-size:18pt;color:#FFD700;font-weight:700}
  table{width:100%;border-collapse:collapse;margin-bottom:6mm;font-size:10pt}
  thead th{background:#1A1F2C;color:#FFD700;text-align:start;padding:3mm 2mm;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  tbody td{padding:2.5mm;border-bottom:1px solid #ddd;vertical-align:top}
  .num{text-align:center;font-family:ui-monospace,Menlo,monospace}
  .mono{font-family:ui-monospace,Menlo,monospace;color:#0d4ed8}
  .notes-block{border:1px solid #ccc;border-radius:3px;padding:3mm;margin:4mm 0;font-size:10pt;color:#333;min-height:14mm}
  .sig-grid{display:grid;grid-template-columns:1fr 1fr;gap:8mm;margin-top:14mm}
  .sig-box{border:1px solid #1A1F2C;border-radius:4px;padding:4mm;min-height:38mm;display:flex;flex-direction:column;gap:2mm}
  .sig-title{font-weight:700;color:#1A1F2C;font-size:11pt;border-bottom:1px solid #ddd;padding-bottom:2mm;margin-bottom:2mm}
  .sig-row{display:flex;justify-content:space-between;font-size:9.5pt;color:#333}
  .sig-k{color:#666}
  .sig-v{font-weight:600}
  .sig-line{margin-top:auto;border-top:1px dashed #999;padding-top:1mm;text-align:center;font-size:8pt;color:#888}
  .sig-line::before{content:"—"}
  .footer{margin-top:8mm;font-size:8pt;color:#888;text-align:center}
  @page{size:A4;margin:0}
</style>
</head>
<body>
  <div class="brand">
    <div class="b-name">${t(s.brand)}</div>
    <div class="b-doc">${t(s.doc_no)}: ${t(o.txn_no)}</div>
  </div>
  <h1>${t(o.title)}</h1>
  <div class="meta">
    <div><div class="k">${t(s.date)}</div><div class="v">${t(g(o.txn_date))}</div></div>
    <div><div class="k">${t(s.reference)}</div><div class="v">${t(o.reference??"—")}</div></div>
    <div><div class="k">${t(s.status)}</div><div class="v">${t(o.status??"—")}</div></div>
  </div>
  <div class="wh-strip">
    <div class="wh-cell">
      <div class="k">${t(s.from)}</div>
      <div class="v">${t(o.from_warehouse??"—")}</div>
    </div>
    <div class="wh-arrow">${_==="rtl"?"←":"→"}</div>
    <div class="wh-cell">
      <div class="k">${t(s.to)}</div>
      <div class="v">${t(o.to_warehouse??"—")}</div>
    </div>
  </div>
  <table>
    <thead><tr>
      <th style="width:8%">${t(s.line)}</th>
      <th style="width:18%">${t(s.part_no)}</th>
      <th>${t(s.description)}</th>
      <th style="width:10%">${t(s.qty)}</th>
      <th style="width:10%">${t(s.unit)}</th>
      <th style="width:22%">${t(s.notes)}</th>
    </tr></thead>
    <tbody>${r||'<tr><td colspan="6" style="text-align:center;color:#999;padding:8mm">—</td></tr>'}</tbody>
  </table>
  ${o.notes?`<div class="notes-block"><strong>${t(s.notes)}:</strong> ${t(o.notes)}</div>`:""}
  <div class="sig-grid">
    ${v(s.signature_sender,o.delivered_by)}
    ${v(s.signature_receiver,o.received_by)}
  </div>
  <div class="footer">${t(s.printed_at)}: ${t(c)}</div>
</body></html>`}const T="[[REC_JSON]]",E=o=>o.split(T)[0]?.trim()??"",re=o=>{const u={is_delegated:!1,recipient_name:"",recipient_title:"",recipient_empno:"",receipt_time:""};if(!o)return u;const s=o.split(T)[1];if(!s)return u;try{return{...u,...JSON.parse(s)}}catch{return u}},oe=(o,u)=>{const s=E(o);return u.is_delegated||u.recipient_name||u.recipient_title||u.recipient_empno||u.receipt_time?`${s}${T}${JSON.stringify(u)}`:s},N=o=>o==="in"?"wms.nav.receipts":o==="out"?"wms.nav.issues":o==="transfer"?"wms.nav.transfers":"wms.txn.adjustment",W=o=>({line_no:o,item_id:"",qty:1,unit:"PCS",notes:""});function _e(){const{type:o,id:u}=V(),s=X(),{t:e,language:_}=Y(),{toast:b}=Z(),c=o??"in",g=!u||u==="new",[r,v]=h.useState({txn_no:"",txn_type:c,txn_date:new Date().toISOString().slice(0,10),status:"draft",party_name:"",reference:"",notes:"",from_warehouse_id:null,to_warehouse_id:null}),[d,$]=h.useState({is_delegated:!1,recipient_name:"",recipient_title:"",recipient_empno:"",receipt_time:new Date().toTimeString().slice(0,5)}),[k,z]=h.useState([W(1)]),[q,R]=h.useState([]),[A,B]=h.useState([]),[D,I]=h.useState(!1),w=ee;h.useEffect(()=>{let n=!1;return(async()=>{const p=await w.from("warehouses").select("id,code,name_ar,name_en").order("code",{ascending:!0}),m=await w.from("items_master").select("id,part_no,description,default_unit,name_ar,name_en").order("part_no",{ascending:!0});n||(R(p.data??[]),B(m.data??[]))})(),()=>{n=!0}},[w]),h.useEffect(()=>{if(g||!u)return;let n=!1;return(async()=>{const p=await w.from("inv_transactions").select("id,txn_no,txn_type,txn_date,status,party_name,reference,notes,from_warehouse_id,to_warehouse_id").eq("id",u),m=await w.from("inv_transaction_items").select("id,line_no,item_id,qty,unit,notes").eq("transaction_id",u);if(n)return;const l=p.data?.[0];if(l){const a=re(l.notes);v({...l,party_name:l.party_name??"",reference:l.reference??"",notes:E(l.notes??"")}),$(a)}const f=(m.data??[]).sort((a,j)=>a.line_no-j.line_no);f.length&&z(f.map(a=>({...a,notes:a.notes??"",unit:a.unit??"PCS"})))})(),()=>{n=!0}},[u,g,w]);const O=h.useCallback(n=>{const p=(_==="ar"?n.name_ar:n.name_en)||n.description;return`${n.part_no} — ${p}`},[_]),S=(n,p)=>z(m=>m.map((l,f)=>f===n?{...l,...p}:l)),U=()=>z(n=>[...n,W(n.length+1)]),P=n=>z(p=>p.filter((m,l)=>l!==n).map((m,l)=>({...m,line_no:l+1}))),G=()=>r.txn_no.trim()?r.txn_date?c!=="transfer"&&!r.party_name.trim()?e("wms.form.err-party"):c==="in"&&!r.to_warehouse_id?e("wms.form.err-to-wh"):c==="out"&&!r.from_warehouse_id?e("wms.form.err-from-wh"):c==="transfer"&&(!r.from_warehouse_id||!r.to_warehouse_id)?e("wms.form.err-wh"):k.filter(p=>p.item_id&&p.qty>0).length?null:e("wms.form.err-lines"):e("wms.form.err-date"):e("wms.form.err-txn-no"),L=h.useCallback(async n=>{const p=G();if(p)return b({title:p,variant:"destructive"}),null;I(!0);try{const m={txn_no:r.txn_no.trim(),txn_type:c,txn_date:r.txn_date,status:n?"posted":"draft",party_name:r.party_name||null,reference:r.reference||null,notes:oe(r.notes,d)||null,from_warehouse_id:r.from_warehouse_id,to_warehouse_id:r.to_warehouse_id,...n?{posted_at:new Date().toISOString()}:{}};let l=r.id;if(g||!l){const{data:a,error:j}=await w.from("inv_transactions").insert(m).select().single();if(j||!a)throw j??new Error("insert failed");l=a.id}else{const{error:a}=await w.from("inv_transactions").update(m).eq("id",l);if(a)throw a;await w.from("inv_transaction_items").delete().eq("transaction_id",l)}const f=k.filter(a=>a.item_id&&a.qty>0).map(a=>({transaction_id:l,line_no:a.line_no,item_id:a.item_id,qty:a.qty,unit:a.unit||null,notes:a.notes||null}));if(f.length){const{error:a}=await w.from("inv_transaction_items").insert(f).select().single();a&&console.warn(a)}return b({title:e(n?"wms.form.toast-posted":"wms.form.toast-saved")}),v(a=>({...a,id:l,status:n?"posted":"draft"})),l??null}catch(m){return console.error(m),b({title:e("wms.form.toast-error"),variant:"destructive"}),null}finally{I(!1)}},[r,k,c,g,w,e,b]),H=()=>{const n=f=>{const a=q.find(j=>j.id===f);return a?_==="ar"?a.name_ar:a.name_en||a.name_ar:null},p=new Map(A.map(f=>[f.id,f])),m=k.filter(f=>f.item_id).map(f=>{const a=p.get(f.item_id);return{line_no:f.line_no,part_no:a?.part_no,qty:f.qty,unit:f.unit,notes:f.notes,description:a?(_==="ar"?a.name_ar:a.name_en)||a.description:"—"}});if(c==="transfer"){const f=se({title:e("wms.nav.transfers"),txn_no:r.txn_no,txn_date:r.txn_date,reference:r.reference,status:e(`wms.status.${r.status}`),notes:r.notes,from_warehouse:n(r.from_warehouse_id),to_warehouse:n(r.to_warehouse_id),delivered_by:d.recipient_name||null,received_by:null},m,{brand:e("wms.brand.name"),doc_no:e("wms.col.txn-no"),date:e("wms.col.date"),reference:e("wms.col.reference"),status:e("wms.col.status"),from:e("wms.form.from-wh"),to:e("wms.form.to-wh"),notes:e("wms.form.notes"),line:e("wms.col.line"),part_no:e("wms.col.part-no"),description:e("wms.col.name"),qty:e("wms.col.qty"),unit:e("wms.col.unit"),signature_sender:e("wms.transfer.sig-sender"),signature_receiver:e("wms.transfer.sig-receiver"),printed_at:e("wms.form.printed-at"),delivered_by_label:e("wms.transfer.delivered-by"),received_by_label:e("wms.transfer.received-by"),date_label:e("wms.col.date")},_);M(f,`${e("wms.nav.transfers")} — ${r.txn_no}`);return}const l=ie({title:e(N(c)),txn_no:r.txn_no,txn_date:r.txn_date,party_name:r.party_name,reference:r.reference,status:e(`wms.status.${r.status}`),notes:r.notes,from_warehouse:n(r.from_warehouse_id),to_warehouse:n(r.to_warehouse_id),recipient_name:d.recipient_name,recipient_title:d.recipient_title,recipient_empno:d.recipient_empno,receipt_time:d.receipt_time,is_delegated:d.is_delegated},m,{brand:e("wms.brand.name"),doc_no:e("wms.col.txn-no"),date:e("wms.col.date"),party:e("wms.col.party"),reference:e("wms.col.reference"),status:e("wms.col.status"),from:e("wms.form.from-wh"),to:e("wms.form.to-wh"),notes:e("wms.form.notes"),line:e("wms.col.line"),part_no:e("wms.col.part-no"),description:e("wms.col.name"),qty:e("wms.col.qty"),unit:e("wms.col.unit"),signature:e("wms.form.signature"),printed_at:e("wms.form.printed-at"),recipient_info:e("wms.form.recipient-info"),recipient_name:e("wms.form.recipient-name"),recipient_title:e("wms.form.recipient-title"),recipient_empno:e("wms.form.recipient-empno"),receipt_time:e("wms.form.receipt-time"),delegation:e("wms.form.delegation")},_);M(l,`${e(N(c))} — ${r.txn_no}`)},J=c==="out"||c==="transfer"||c==="adjustment",K=c==="in"||c==="transfer"||c==="adjustment",Q=h.useMemo(()=>`${e(N(c))} — ${g?e("wms.form.new"):r.txn_no}`,[c,g,r.txn_no,e]);return i.jsxs(te,{title:Q,subtitle:e(g?"wms.form.new-sub":"wms.form.edit-sub"),children:[i.jsxs("div",{className:"wms-form-grid",children:[i.jsx(x,{label:e("wms.col.txn-no"),children:i.jsx(y,{value:r.txn_no,onChange:n=>v({...r,txn_no:n.target.value})})}),i.jsx(x,{label:e("wms.col.date"),children:i.jsx(y,{type:"date",value:r.txn_date,onChange:n=>v({...r,txn_date:n.target.value})})}),i.jsx(x,{label:e("wms.col.reference"),children:i.jsx(y,{value:r.reference,onChange:n=>v({...r,reference:n.target.value})})}),c!=="transfer"&&i.jsx(x,{label:e("wms.col.party"),children:i.jsx(y,{value:r.party_name,onChange:n=>v({...r,party_name:n.target.value})})}),J&&i.jsx(x,{label:e("wms.form.from-wh"),children:i.jsxs(F,{value:r.from_warehouse_id??"",onChange:n=>v({...r,from_warehouse_id:n.target.value||null}),children:[i.jsx("option",{value:"",children:"—"}),q.map(n=>i.jsxs("option",{value:n.id,children:[n.code," · ",_==="ar"?n.name_ar:n.name_en||n.name_ar]},n.id))]})}),K&&i.jsx(x,{label:e("wms.form.to-wh"),children:i.jsxs(F,{value:r.to_warehouse_id??"",onChange:n=>v({...r,to_warehouse_id:n.target.value||null}),children:[i.jsx("option",{value:"",children:"—"}),q.map(n=>i.jsxs("option",{value:n.id,children:[n.code," · ",_==="ar"?n.name_ar:n.name_en||n.name_ar]},n.id))]})})]}),(c==="in"||c==="out")&&i.jsxs(i.Fragment,{children:[i.jsxs("div",{className:"wms-section",children:[i.jsxs("div",{className:"wms-section-title",children:["⚑ ",e("wms.form.delegation")]}),i.jsxs("label",{className:"wms-checkbox-row",children:[i.jsx("input",{type:"checkbox",checked:d.is_delegated,onChange:n=>$({...d,is_delegated:n.target.checked})}),e("wms.form.delegation")]})]}),i.jsxs("div",{className:"wms-section",children:[i.jsxs("div",{className:"wms-section-title",children:["▣ ",e("wms.form.recipient-info")]}),i.jsxs("div",{className:"wms-form-grid",style:{marginBottom:0},children:[i.jsx(x,{label:e("wms.form.recipient-name"),children:i.jsx(y,{value:d.recipient_name,onChange:n=>$({...d,recipient_name:n.target.value})})}),i.jsx(x,{label:e("wms.form.recipient-title"),children:i.jsx(y,{value:d.recipient_title,onChange:n=>$({...d,recipient_title:n.target.value})})}),i.jsx(x,{label:e("wms.form.recipient-empno"),children:i.jsx(y,{value:d.recipient_empno,onChange:n=>$({...d,recipient_empno:n.target.value})})}),i.jsx(x,{label:e("wms.form.receipt-time"),children:i.jsx(y,{type:"time",value:d.receipt_time,onChange:n=>$({...d,receipt_time:n.target.value})})})]})]})]}),i.jsxs("div",{className:"wms-lines-actions",children:[i.jsx("span",{className:"wms-lines-title",children:e("wms.form.lines")}),i.jsxs(C,{size:"sm",variant:"ghost",onClick:U,children:["+ ",e("wms.form.add-line")]})]}),i.jsx("div",{className:"wms-table-wrap",children:i.jsxs("table",{className:"wms-table is-edit",children:[i.jsx("thead",{children:i.jsxs("tr",{children:[i.jsx("th",{style:{width:50},children:e("wms.col.line")}),i.jsx("th",{children:e("wms.col.part-no")}),i.jsx("th",{style:{width:100},children:e("wms.col.qty")}),i.jsx("th",{style:{width:90},children:e("wms.col.unit")}),i.jsx("th",{children:e("wms.form.notes")}),i.jsx("th",{style:{width:40}})]})}),i.jsx("tbody",{children:k.map((n,p)=>i.jsxs("tr",{children:[i.jsx("td",{className:"wms-td-mono",children:n.line_no}),i.jsx("td",{children:i.jsxs(F,{value:n.item_id,onChange:m=>{const l=A.find(f=>f.id===m.target.value);S(p,{item_id:m.target.value,unit:l?.default_unit??n.unit})},children:[i.jsx("option",{value:"",children:"—"}),A.map(m=>i.jsx("option",{value:m.id,children:O(m)},m.id))]})}),i.jsx("td",{children:i.jsx(y,{type:"number",min:0,step:"any",value:n.qty,onChange:m=>S(p,{qty:Number(m.target.value)||0})})}),i.jsx("td",{children:i.jsx(y,{value:n.unit,onChange:m=>S(p,{unit:m.target.value})})}),i.jsx("td",{children:i.jsx(y,{value:n.notes,onChange:m=>S(p,{notes:m.target.value})})}),i.jsx("td",{children:i.jsx("button",{className:"wms-icon-btn",type:"button",onClick:()=>P(p),"aria-label":"delete",children:"×"})})]},p))})]})}),i.jsx("div",{className:"wms-form-grid",style:{marginTop:"1rem"},children:i.jsx("div",{style:{gridColumn:"1 / -1"},children:i.jsx(x,{label:e("wms.form.notes"),children:i.jsx(ne,{value:r.notes,onChange:n=>v({...r,notes:n.target.value})})})})}),i.jsxs("div",{className:"wms-form-footer",children:[i.jsx(C,{variant:"ghost",onClick:()=>s(-1),children:e("wms.form.cancel")}),i.jsx(C,{variant:"ghost",onClick:H,children:e("wms.form.print")}),i.jsx(C,{variant:"ghost",disabled:D,onClick:()=>L(!1),children:e("wms.form.save-draft")}),i.jsx(C,{variant:"primary",disabled:D,onClick:async()=>{const n=await L(!0);n&&g&&s(`/wms/txn/${c}/${n}`,{replace:!0})},children:e("wms.form.post")})]})]})}export{_e as default};
