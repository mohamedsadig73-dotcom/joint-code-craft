import{j as s}from"./ui-vendor-B6rM8d5N.js";import{r as w}from"./react-vendor-Bn7N0-Jb.js";import{D as y,b,c as v,d as S,e as k}from"./dialog-fAW79Y5a.js";import{a as $,B as x,X as j}from"./index-C-3CyeeB.js";import{P}from"./printer-BRbs7QbC.js";function M(){const t=[];return document.querySelectorAll("style").forEach(e=>{const r=e.textContent??"";r.trim()&&t.push(`<style>${r}</style>`)}),document.querySelectorAll('link[rel="stylesheet"]').forEach(e=>{const r=e.getAttribute("href")??"";r&&!r.startsWith("chrome-extension:")&&!r.startsWith("moz-extension:")&&!r.startsWith("data:")&&t.push(`<link rel="stylesheet" href="${r}">`)}),t.join(`
`)}const A=`
  * { box-sizing: border-box; }
  body { margin: 0; color: #000; background: #fff; font-family: 'Segoe UI', Tahoma, Arial, sans-serif; font-size: 12px; line-height: 1.4; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #555; padding: 4px 6px; text-align: start; vertical-align: top; }
  thead { display: table-header-group; background: #eee; }
  tr { page-break-inside: avoid; }
  h1, h2, h3 { margin: 0 0 8px; }
  img { max-width: 100%; height: auto; }
  .print\\:hidden, [data-print-hide="true"] { display: none !important; }
`;function m(t,e){const{title:r,paperSize:o="A4",orientation:l="portrait",marginMm:a=10,dir:i="rtl",lang:n="ar",safeMode:d=!1}=e,p=d?"":M(),u=Math.max(0,Math.min(40,Math.round(a)));return`<!DOCTYPE html>
<html dir="${i}" lang="${n}">
  <head>
    <meta charset="utf-8" />
    <title>${E(r)}</title>
    ${p}
    <style>
      @page { size: ${o} ${l}; margin: ${u}mm; }
      html, body { background: white !important; margin: 0; padding: 0; }
      ${d?A:`body {
        font-family: 'Segoe UI Arabic', 'Cairo', Arial, sans-serif;
        color: #000;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      .print-sheet { width: 100%; min-height: auto; padding: 0; margin: 0; box-sizing: border-box; }
      .print:hidden, [data-print-hide="true"] { display: none !important; }
      thead { display: table-header-group; }
      tr { page-break-inside: avoid; }
      img { max-width: 100%; }`}
    </style>
  </head>
  <body>${t}</body>
</html>`}function E(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const g="dts.print.log",D=50;function c(t){try{const e=localStorage.getItem(g),r=e?JSON.parse(e):[];r.unshift({ts:Date.now(),...t}),localStorage.setItem(g,JSON.stringify(r.slice(0,D)))}catch{}}function I(){try{const t=localStorage.getItem(g);return t?JSON.parse(t):[]}catch{return[]}}async function z(t,e){const r=e.windowsMode??"auto",o=e.autoSafeRetry??!0,l=typeof window<"u"&&!!window.electronAPI?.printHTML;if(l&&r==="preview"){const i=m(t,e);return c({level:"info",message:`طباعة عبر المعاينة الداخلية: ${e.title}`}),{ok:!1,reason:"forced-preview-mode",transport:"preview",html:i,failedStep:"preview"}}if(l&&(r==="auto"||r==="native")){const i=m(t,e);try{return await window.electronAPI.printHTML(i),c({level:"info",message:`طباعة ناجحة: ${e.title}`,detail:`mode=${r}`}),{ok:!0,transport:"electron"}}catch(n){const d=n instanceof Error?n.message:String(n);if(c({level:"warn",message:"فشل الطباعة (المحاولة الأولى)",detail:`mode=${r} | ${d}`}),o){const p=m(t,{...e,safeMode:!0});try{return await window.electronAPI.printHTML(p),c({level:"info",message:`نجحت الطباعة في الوضع الآمن: ${e.title}`}),{ok:!0,transport:"electron",safeMode:!0}}catch(u){const f=u instanceof Error?u.message:String(u);return c({level:"error",message:"فشل الوضع الآمن أيضاً",detail:f}),{ok:!1,reason:f,transport:"electron",html:p,failedStep:h(f),safeMode:!0}}}return{ok:!1,reason:d,transport:"electron",html:i,failedStep:h(d)}}}const a=m(t,e);try{const i=document.title;return document.title=e.title,await new Promise(n=>setTimeout(n,80)),window.print(),setTimeout(()=>{document.title=i},600),c({level:"info",message:`طباعة عبر المتصفح: ${e.title}`}),{ok:!0,transport:"browser"}}catch(i){const n=i instanceof Error?i.message:String(i);return c({level:"error",message:"فشل طباعة المتصفح",detail:n}),{ok:!1,reason:n,transport:"browser",html:a,failedStep:h(n)}}}function h(t){const e=t.toLowerCase();return e.includes("ipc")||e.includes("bridge")||e.includes("handle")||e.includes("channel")?"bridge":e.includes("printer")||e.includes("no devices")||e.includes("not found")||e.includes("device")?"printer":e.includes("css")||e.includes("style")||e.includes("layer")?"css":e.includes("window")||e.includes("preview")||e.includes("loadfile")?"preview":"unknown"}function N(){const t=[],e=`
    <div class="print-sheet" style="padding:10mm">
      <h1>فاتورة تجريبية — Sample Invoice</h1>
      <table>
        <thead><tr><th>#</th><th>Item</th><th>Qty</th><th>Price</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>Widget A</td><td>2</td><td>50.00</td></tr>
          <tr><td>2</td><td>Widget B</td><td>1</td><td>75.50</td></tr>
        </tbody>
      </table>
    </div>`,r=m(e,{title:"self-test-normal",paperSize:"A4",orientation:"portrait",marginMm:10});t.push({name:"normal-non-empty",ok:r.length>200,detail:`${r.length} chars`}),t.push({name:"normal-has-page-rule",ok:r.includes("@page"),detail:"@page directive present"}),t.push({name:"normal-has-body",ok:r.includes("Sample Invoice"),detail:"invoice body rendered"});const o=m(e,{title:"self-test-safe",paperSize:"A4",orientation:"portrait",marginMm:10,safeMode:!0});t.push({name:"safe-non-empty",ok:o.length>200,detail:`${o.length} chars`}),t.push({name:"safe-no-bundle-css",ok:!o.includes("/assets/"),detail:"no Vite asset links in safe mode"}),t.push({name:"safe-has-page-rule",ok:o.includes("@page"),detail:"@page directive present"});const l=t.every(a=>a.ok);return c({level:l?"info":"error",message:`Print self-test ${l?"passed":"failed"}`,detail:t.map(a=>`${a.ok?"✓":"✗"} ${a.name}`).join(" | ")}),{ok:l,checks:t,previewHtml:r}}const W=Object.freeze(Object.defineProperty({__proto__:null,buildPrintHTML:m,logPrintEvent:c,printDocument:z,readPrintLog:I,runPrintSelfTest:N},Symbol.toStringTag,{value:"Module"}));function B({open:t,onOpenChange:e,html:r,reason:o}){const{t:l}=$(),a=w.useRef(null);w.useEffect(()=>{if(!t)return;const n=a.current;n&&(n.srcdoc=r)},[t,r]);const i=()=>{const n=a.current?.contentWindow;if(n)try{n.focus(),n.print()}catch(d){console.warn("Iframe print failed:",d)}};return s.jsx(y,{open:t,onOpenChange:e,children:s.jsxs(b,{className:"max-w-5xl w-[95vw] h-[90vh] p-0 flex flex-col gap-0",children:[s.jsxs(v,{className:"p-4 border-b flex flex-row items-center justify-between space-y-0",children:[s.jsxs("div",{className:"flex-1",children:[s.jsx(S,{children:l("printPreview")}),o&&s.jsx(k,{className:"text-xs mt-1 text-destructive",children:o})]}),s.jsxs("div",{className:"flex items-center gap-2",children:[s.jsxs(x,{onClick:i,size:"sm",children:[s.jsx(P,{className:"w-4 h-4 me-1.5"}),l("print")]}),s.jsx(x,{variant:"ghost",size:"icon",onClick:()=>e(!1),children:s.jsx(j,{className:"w-4 h-4"})})]})]}),s.jsx("iframe",{ref:a,title:"print-preview",className:"w-full flex-1 bg-muted/30 border-0",sandbox:"allow-same-origin allow-modals"})]})})}export{B as P,N as a,W as b,c as l,z as p,I as r};
