import{j as l}from"./ui-vendor-B6rM8d5N.js";import{r as w}from"./react-vendor-Bn7N0-Jb.js";import{D as y,b as x,c as v,d as k,e as S}from"./dialog-sYUI33dc.js";import{a as $,B as b,X as j}from"./index-Dm8Fnk3z.js";import{P}from"./printer-ywsLzge2.js";function M(){const t=[];return document.querySelectorAll("style").forEach(e=>{const r=e.textContent??"";r.trim()&&t.push(`<style>${r}</style>`)}),document.querySelectorAll('link[rel="stylesheet"]').forEach(e=>{const r=e.getAttribute("href")??"";r&&!r.startsWith("chrome-extension:")&&!r.startsWith("moz-extension:")&&!r.startsWith("data:")&&t.push(`<link rel="stylesheet" href="${r}">`)}),t.join(`
`)}const D=`
  * { box-sizing: border-box; }
  body { margin: 0; color: #000; background: #fff; font-family: 'Segoe UI', Tahoma, Arial, sans-serif; font-size: 12px; line-height: 1.4; }
  table { width: 100%; border-collapse: collapse; }
  th, td { border: 1px solid #555; padding: 4px 6px; text-align: start; vertical-align: top; }
  thead { display: table-header-group; background: #eee; }
  tr { page-break-inside: avoid; }
  h1, h2, h3 { margin: 0 0 8px; }
  img { max-width: 100%; height: auto; }
  .print\\:hidden, [data-print-hide="true"] { display: none !important; }
`;function f(t,e){const{title:r,paperSize:c="A4",orientation:d="portrait",marginMm:a=10,dir:i="rtl",lang:n="ar",safeMode:o=!1}=e,u=o?"":M(),s=Math.max(0,Math.min(40,Math.round(a)));return`<!DOCTYPE html>
<html dir="${i}" lang="${n}">
  <head>
    <meta charset="utf-8" />
    <title>${E(r)}</title>
    ${u}
    <style>
      @page { size: ${c} ${d}; margin: ${s}mm; }
      html, body { background: white !important; margin: 0; padding: 0; }
      ${o?D:`body {
        font-family: 'Segoe UI Arabic', 'Cairo', Arial, sans-serif;
        color: #000;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      .print-sheet { width: 100%; min-height: auto; padding: 0; margin: 0; box-sizing: border-box; }
      .print:hidden, [data-print-hide="true"] { display: none !important; }
      thead { display: table-header-group; }
      tr { page-break-inside: avoid; }
      img { max-width: 100%; }`}
    </style>
  </head>
  <body>${t}</body>
</html>`}function E(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const g="dts.print.log",A=50;function m(t){try{const e=localStorage.getItem(g),r=e?JSON.parse(e):[];r.unshift({ts:Date.now(),...t}),localStorage.setItem(g,JSON.stringify(r.slice(0,A)))}catch{}}function I(){try{const t=localStorage.getItem(g);return t?JSON.parse(t):[]}catch{return[]}}async function z(t,e){const r=e.windowsMode??"auto",c=e.autoSafeRetry??!0,d=typeof window<"u"&&!!window.electronAPI?.printHTML;if(d&&r==="preview"){const i=f(t,e);return m({level:"info",message:`طباعة عبر المعاينة الداخلية: ${e.title}`}),{ok:!1,reason:"forced-preview-mode",transport:"preview",html:i,failedStep:"preview"}}if(d&&(r==="auto"||r==="native")){const i=f(t,e);try{const n=await window.electronAPI.printHTML(i),o=typeof n=="object"&&n!==null?n.path:void 0;return m({level:"info",message:`تم إنشاء ملف PDF للطباعة: ${e.title}`,detail:`mode=${r}${o?` | ${o}`:""}`}),{ok:!0,transport:"electron",path:o}}catch(n){const o=n instanceof Error?n.message:String(n);if(m({level:"warn",message:"فشل الطباعة (المحاولة الأولى)",detail:`mode=${r} | ${o}`}),c){const u=f(t,{...e,safeMode:!0});try{const s=await window.electronAPI.printHTML(u),p=typeof s=="object"&&s!==null?s.path:void 0;return m({level:"info",message:`تم إنشاء PDF في الوضع الآمن: ${e.title}`,detail:p}),{ok:!0,transport:"electron",safeMode:!0,path:p}}catch(s){const p=s instanceof Error?s.message:String(s);return m({level:"error",message:"فشل الوضع الآمن أيضاً",detail:p}),{ok:!1,reason:p,transport:"electron",html:u,failedStep:h(p),safeMode:!0}}}return{ok:!1,reason:o,transport:"electron",html:i,failedStep:h(o)}}}const a=f(t,e);try{const i=document.title;return document.title=e.title,await new Promise(n=>setTimeout(n,80)),window.print(),setTimeout(()=>{document.title=i},600),m({level:"info",message:`طباعة عبر المتصفح: ${e.title}`}),{ok:!0,transport:"browser"}}catch(i){const n=i instanceof Error?i.message:String(i);return m({level:"error",message:"فشل طباعة المتصفح",detail:n}),{ok:!1,reason:n,transport:"browser",html:a,failedStep:h(n)}}}function h(t){const e=t.toLowerCase();return e.includes("ipc")||e.includes("bridge")||e.includes("handle")||e.includes("channel")?"bridge":e.includes("printer")||e.includes("no devices")||e.includes("not found")||e.includes("device")?"printer":e.includes("css")||e.includes("style")||e.includes("layer")?"css":e.includes("window")||e.includes("preview")||e.includes("loadfile")?"preview":"unknown"}function L(){const t=[],e=`
    <div class="print-sheet" style="padding:10mm">
      <h1>فاتورة تجريبية — Sample Invoice</h1>
      <table>
        <thead><tr><th>#</th><th>Item</th><th>Qty</th><th>Price</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>Widget A</td><td>2</td><td>50.00</td></tr>
          <tr><td>2</td><td>Widget B</td><td>1</td><td>75.50</td></tr>
        </tbody>
      </table>
    </div>`,r=f(e,{title:"self-test-normal",paperSize:"A4",orientation:"portrait",marginMm:10});t.push({name:"normal-non-empty",ok:r.length>200,detail:`${r.length} chars`}),t.push({name:"normal-has-page-rule",ok:r.includes("@page"),detail:"@page directive present"}),t.push({name:"normal-has-body",ok:r.includes("Sample Invoice"),detail:"invoice body rendered"});const c=f(e,{title:"self-test-safe",paperSize:"A4",orientation:"portrait",marginMm:10,safeMode:!0});t.push({name:"safe-non-empty",ok:c.length>200,detail:`${c.length} chars`}),t.push({name:"safe-no-bundle-css",ok:!c.includes("/assets/"),detail:"no Vite asset links in safe mode"}),t.push({name:"safe-has-page-rule",ok:c.includes("@page"),detail:"@page directive present"});const d=t.every(a=>a.ok);return m({level:d?"info":"error",message:`Print self-test ${d?"passed":"failed"}`,detail:t.map(a=>`${a.ok?"✓":"✗"} ${a.name}`).join(" | ")}),{ok:d,checks:t,previewHtml:r}}const C=Object.freeze(Object.defineProperty({__proto__:null,buildPrintHTML:f,logPrintEvent:m,printDocument:z,readPrintLog:I,runPrintSelfTest:L},Symbol.toStringTag,{value:"Module"}));function B({open:t,onOpenChange:e,html:r,reason:c}){const{t:d}=$(),a=w.useRef(null);w.useEffect(()=>{if(!t)return;const n=a.current;n&&(n.srcdoc=r)},[t,r]);const i=()=>{const n=a.current?.contentWindow,o=a.current?.contentDocument;if(!(!n||!o))try{const u=new Blob([o.documentElement.outerHTML],{type:"text/html"}),s=URL.createObjectURL(u),p=window.open(s,"_blank","noopener,noreferrer");window.setTimeout(()=>URL.revokeObjectURL(s),3e4),p||(n.focus(),n.print())}catch(u){console.warn("Iframe print failed:",u)}};return l.jsx(y,{open:t,onOpenChange:e,children:l.jsxs(x,{className:"max-w-5xl w-[95vw] h-[90vh] p-0 flex flex-col gap-0",children:[l.jsxs(v,{className:"p-4 border-b flex flex-row items-center justify-between space-y-0",children:[l.jsxs("div",{className:"flex-1",children:[l.jsx(k,{children:d("printPreview")}),c&&l.jsx(S,{className:"text-xs mt-1 text-destructive",children:c})]}),l.jsxs("div",{className:"flex items-center gap-2",children:[l.jsxs(b,{onClick:i,size:"sm",children:[l.jsx(P,{className:"w-4 h-4 me-1.5"}),d("print")]}),l.jsx(b,{variant:"ghost",size:"icon",onClick:()=>e(!1),children:l.jsx(j,{className:"w-4 h-4"})})]})]}),l.jsx("iframe",{ref:a,title:"print-preview",className:"w-full flex-1 bg-muted/30 border-0",sandbox:"allow-same-origin allow-modals"})]})})}export{B as P,L as a,C as b,m as l,z as p,I as r};
