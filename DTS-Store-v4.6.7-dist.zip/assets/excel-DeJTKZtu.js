import{E as h}from"./excel-export-THpPploz.js";async function p(t,d,s,c){const e=new h.Workbook;e.creator="WMS";const n=e.addWorksheet(d,{views:[{rightToLeft:!1}]});n.columns=s.map(a=>({header:a.header,key:a.key,width:a.width??18}));const r=n.getRow(1);r.font={bold:!0,color:{argb:"FFFFD700"}},r.fill={type:"pattern",pattern:"solid",fgColor:{argb:"FF1A1F2C"}},r.alignment={horizontal:"center",vertical:"middle"},r.height=22,c.forEach(a=>n.addRow(a)),n.eachRow({includeEmpty:!1},(a,b)=>{b!==1&&a.eachCell(g=>{g.border={top:{style:"thin",color:{argb:"FFE0E0E0"}},bottom:{style:"thin",color:{argb:"FFE0E0E0"}},left:{style:"thin",color:{argb:"FFE0E0E0"}},right:{style:"thin",color:{argb:"FFE0E0E0"}}}})});const o=await e.xlsx.writeBuffer(),l=new Blob([o],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),m=URL.createObjectURL(l),i=document.createElement("a");i.href=m,i.download=t,document.body.appendChild(i),i.click(),i.remove(),setTimeout(()=>URL.revokeObjectURL(m),1500)}function u(t){const d=t.language==="ar"?"rtl":"ltr",s=t.language==="ar"?"'Segoe UI Arabic','Segoe UI',Tahoma,Arial,sans-serif":"'Inter','Segoe UI',system-ui,sans-serif",c=new Date().toLocaleString("en-GB"),e=o=>o==null?"":String(o).replace(/[&<>"']/g,l=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[l]),n=t.columns.map(o=>`<th>${e(o.header)}</th>`).join(""),r=t.rows.map(o=>`<tr>${t.columns.map(l=>`<td>${e(o[l.key])}</td>`).join("")}</tr>`).join("");return`<!doctype html>
<html lang="${t.language}" dir="${d}">
<head><meta charset="utf-8"/><title>${e(t.title)}</title>
<style>
  body{font-family:${s};margin:0;padding:14mm;color:#111;font-size:10pt}
  .brand{display:flex;justify-content:space-between;align-items:end;
    border-bottom:2px solid #1A1F2C;padding-bottom:3mm;margin-bottom:5mm}
  .b-name{font-weight:700;font-size:13pt;color:#1A1F2C}
  h1{margin:0 0 1mm;font-size:16pt;color:#1A1F2C}
  .sub{color:#666;font-size:9pt}
  table{width:100%;border-collapse:collapse;font-size:9pt}
  thead th{background:#1A1F2C;color:#FFD700;text-align:start;padding:2.5mm;
    font-size:8.5pt;text-transform:uppercase;letter-spacing:.4px}
  tbody td{padding:2mm;border-bottom:1px solid #ddd}
  tbody tr:nth-child(even) td{background:#fafafa}
  .footer{margin-top:6mm;font-size:8pt;color:#888;text-align:center}
  @page{size:A4 landscape;margin:0}
</style></head>
<body>
  <div class="brand">
    <div><h1>${e(t.title)}</h1>${t.subtitle?`<div class="sub">${e(t.subtitle)}</div>`:""}</div>
    <div class="b-name">${e(t.brand)}</div>
  </div>
  <table><thead><tr>${n}</tr></thead><tbody>${r||`<tr><td colspan="${t.columns.length}" style="text-align:center;color:#999;padding:8mm">—</td></tr>`}</tbody></table>
  <div class="footer">${e(t.printedAtLabel)}: ${e(c)}</div>
</body></html>`}export{u as b,p as e};
