import{j as e}from"./ui-vendor-Dmwbbbfi.js";function r({tone:s="gray",children:a}){return e.jsx("span",{className:`wms-badge wms-badge-${s}`,children:a})}export{r as W};
