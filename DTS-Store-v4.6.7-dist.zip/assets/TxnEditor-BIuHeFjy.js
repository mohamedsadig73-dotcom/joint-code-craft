import{j as t}from"./ui-vendor-Dmwbbbfi.js";import{i as Q,u as V,r as h}from"./react-vendor-BTZHR6BZ.js";import{a as X,b as Y,s as Z}from"./index-B_-QMVe7.js";import{W as ee}from"./WmsCard-DIsBrz-x.js";import{W as C}from"./WmsButton-9xxmv3Hd.js";import{W as w,b as x,a as T,c as te}from"./WmsField-j5pBbvGU.js";import{e as i,w as ne}from"./print-DK2iyTys.js";import"./icons-Cc2ZhWP9.js";import"./supabase-fIMjPNmZ.js";function ie(r,p,o,n){const y=n==="ar"?"rtl":"ltr",j=n==="ar"?"'Segoe UI Arabic','Segoe UI',Tahoma,Arial,sans-serif":"'Inter','Segoe UI',system-ui,sans-serif",l=new Date().toLocaleString("en-GB"),g=_=>{try{return new Date(_).toLocaleDateString("en-GB")}catch{return _}},s=p.map(_=>`
    <tr>
      <td class="num">${i(_.line_no)}</td>
      <td class="mono">${i(_.part_no??"—")}</td>
      <td>${i(_.description??"—")}</td>
      <td class="num">${i(_.qty)}</td>
      <td>${i(_.unit??"—")}</td>
      <td>${i(_.notes??"")}</td>
    </tr>`).join("");return`<!doctype html>
<html lang="${n}" dir="${y}">
<head>
<meta charset="utf-8" />
<title>${i(r.title)} — ${i(r.txn_no)}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:${j};color:#111;margin:0;padding:18mm 14mm;font-size:12pt}
  h1{font-size:20pt;margin:0 0 4mm;color:#1A1F2C}
  .brand{display:flex;justify-content:space-between;align-items:center;
    border-bottom:2px solid #1A1F2C;padding-bottom:4mm;margin-bottom:6mm}
  .brand .b-name{font-weight:700;font-size:14pt;color:#1A1F2C}
  .brand .b-doc{font-family:ui-monospace,Menlo,monospace;font-size:11pt;color:#555}
  .meta{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm 6mm;margin-bottom:6mm;font-size:10pt}
  .meta .k{color:#666;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  .meta .v{font-weight:600;color:#111;margin-top:1mm}
  table{width:100%;border-collapse:collapse;margin-bottom:6mm;font-size:10pt}
  thead th{background:#1A1F2C;color:#FFD700;text-align:start;padding:3mm 2mm;font-size:9pt;text-transform:uppercase;letter-spacing:.5px}
  tbody td{padding:2.5mm;border-bottom:1px solid #ddd;vertical-align:top}
  .num{text-align:center;font-family:ui-monospace,Menlo,monospace}
  .mono{font-family:ui-monospace,Menlo,monospace;color:#0d4ed8}
  .notes-block{border:1px solid #ccc;border-radius:3px;padding:3mm;margin-top:4mm;font-size:10pt;color:#333;min-height:14mm}
  .sig{display:grid;grid-template-columns:1fr 1fr;gap:10mm;margin-top:14mm}
  .sig .box{border-top:1px solid #333;padding-top:2mm;text-align:center;font-size:9pt;color:#555}
  .footer{margin-top:8mm;font-size:8pt;color:#888;text-align:center}
  @page{size:A4;margin:0}
</style>
</head>
<body>
  <div class="brand">
    <div class="b-name">${i(o.brand)}</div>
    <div class="b-doc">${i(o.doc_no)}: ${i(r.txn_no)}</div>
  </div>
  <h1>${i(r.title)}</h1>
  <div class="meta">
    <div><div class="k">${i(o.date)}</div><div class="v">${i(g(r.txn_date))}</div></div>
    <div><div class="k">${i(o.party)}</div><div class="v">${i(r.party_name??"—")}</div></div>
    <div><div class="k">${i(o.reference)}</div><div class="v">${i(r.reference??"—")}</div></div>
    <div><div class="k">${i(o.status)}</div><div class="v">${i(r.status??"—")}</div></div>
    <div><div class="k">${i(o.from)}</div><div class="v">${i(r.from_warehouse??"—")}</div></div>
    <div><div class="k">${i(o.to)}</div><div class="v">${i(r.to_warehouse??"—")}</div></div>
  </div>
  <table>
    <thead><tr>
      <th style="width:8%">${i(o.line)}</th>
      <th style="width:18%">${i(o.part_no)}</th>
      <th>${i(o.description)}</th>
      <th style="width:10%">${i(o.qty)}</th>
      <th style="width:10%">${i(o.unit)}</th>
      <th style="width:22%">${i(o.notes)}</th>
    </tr></thead>
    <tbody>${s||'<tr><td colspan="6" style="text-align:center;color:#999;padding:8mm">—</td></tr>'}</tbody>
  </table>
  ${r.notes?`<div class="notes-block"><strong>${i(o.notes)}:</strong> ${i(r.notes)}</div>`:""}
  ${r.recipient_name||r.recipient_title||r.recipient_empno||r.receipt_time||r.is_delegated?`
  <div class="notes-block">
    <strong>${i(o.recipient_info??"Recipient")}:</strong>
    <div class="meta" style="margin-top:3mm">
      <div><div class="k">${i(o.recipient_name??"Name")}</div><div class="v">${i(r.recipient_name??"—")}</div></div>
      <div><div class="k">${i(o.recipient_title??"Title")}</div><div class="v">${i(r.recipient_title??"—")}</div></div>
      <div><div class="k">${i(o.recipient_empno??"Emp #")}</div><div class="v">${i(r.recipient_empno??"—")}</div></div>
      <div><div class="k">${i(o.receipt_time??"Time")}</div><div class="v">${i(r.receipt_time??"—")}</div></div>
      ${r.is_delegated?`<div><div class="k">${i(o.delegation??"Delegation")}</div><div class="v">✓</div></div>`:""}
    </div>
  </div>`:""}
  <div class="sig">
    <div class="box">${i(o.signature)} 1</div>
    <div class="box">${i(o.signature)} 2</div>
  </div>
  <div class="footer">${i(o.printed_at)}: ${i(l)}</div>
</body></html>`}const L="[[REC_JSON]]",F=r=>r.split(L)[0]?.trim()??"",se=r=>{const p={is_delegated:!1,recipient_name:"",recipient_title:"",recipient_empno:"",receipt_time:""};if(!r)return p;const o=r.split(L)[1];if(!o)return p;try{return{...p,...JSON.parse(o)}}catch{return p}},re=(r,p)=>{const o=F(r);return p.is_delegated||p.recipient_name||p.recipient_title||p.recipient_empno||p.receipt_time?`${o}${L}${JSON.stringify(p)}`:o},A=r=>r==="in"?"wms.nav.receipts":r==="out"?"wms.nav.issues":r==="transfer"?"wms.nav.transfers":"wms.txn.adjustment",E=r=>({line_no:r,item_id:"",qty:1,unit:"PCS",notes:""});function fe(){const{type:r,id:p}=Q(),o=V(),{t:n,language:y}=X(),{toast:j}=Y(),l=r??"in",g=!p||p==="new",[s,_]=h.useState({txn_no:"",txn_type:l,txn_date:new Date().toISOString().slice(0,10),status:"draft",party_name:"",reference:"",notes:"",from_warehouse_id:null,to_warehouse_id:null}),[f,$]=h.useState({is_delegated:!1,recipient_name:"",recipient_title:"",recipient_empno:"",receipt_time:new Date().toTimeString().slice(0,5)}),[b,k]=h.useState([E(1)]),[q,M]=h.useState([]),[z,R]=h.useState([]),[D,I]=h.useState(!1),v=Z;h.useEffect(()=>{let e=!1;return(async()=>{const c=await v.from("warehouses").select("id,code,name_ar,name_en").order("code",{ascending:!0}),m=await v.from("items_master").select("id,part_no,description,default_unit,name_ar,name_en").order("part_no",{ascending:!0});e||(M(c.data??[]),R(m.data??[]))})(),()=>{e=!0}},[v]),h.useEffect(()=>{if(g||!p)return;let e=!1;return(async()=>{const c=await v.from("inv_transactions").select("id,txn_no,txn_type,txn_date,status,party_name,reference,notes,from_warehouse_id,to_warehouse_id").eq("id",p),m=await v.from("inv_transaction_items").select("id,line_no,item_id,qty,unit,notes").eq("transaction_id",p);if(e)return;const a=c.data?.[0];if(a){const d=se(a.notes);_({...a,party_name:a.party_name??"",reference:a.reference??"",notes:F(a.notes??"")}),$(d)}const u=(m.data??[]).sort((d,N)=>d.line_no-N.line_no);u.length&&k(u.map(d=>({...d,notes:d.notes??"",unit:d.unit??"PCS"})))})(),()=>{e=!0}},[p,g,v]);const B=h.useCallback(e=>{const c=(y==="ar"?e.name_ar:e.name_en)||e.description;return`${e.part_no} — ${c}`},[y]),S=(e,c)=>k(m=>m.map((a,u)=>u===e?{...a,...c}:a)),O=()=>k(e=>[...e,E(e.length+1)]),P=e=>k(c=>c.filter((m,a)=>a!==e).map((m,a)=>({...m,line_no:a+1}))),H=()=>s.txn_no.trim()?s.txn_date?l!=="transfer"&&!s.party_name.trim()?n("wms.form.err-party"):l==="in"&&!s.to_warehouse_id?n("wms.form.err-to-wh"):l==="out"&&!s.from_warehouse_id?n("wms.form.err-from-wh"):l==="transfer"&&(!s.from_warehouse_id||!s.to_warehouse_id)?n("wms.form.err-wh"):b.filter(c=>c.item_id&&c.qty>0).length?null:n("wms.form.err-lines"):n("wms.form.err-date"):n("wms.form.err-txn-no"),W=h.useCallback(async e=>{const c=H();if(c)return j({title:c,variant:"destructive"}),null;I(!0);try{const m={txn_no:s.txn_no.trim(),txn_type:l,txn_date:s.txn_date,status:e?"posted":"draft",party_name:s.party_name||null,reference:s.reference||null,notes:re(s.notes,f)||null,from_warehouse_id:s.from_warehouse_id,to_warehouse_id:s.to_warehouse_id,...e?{posted_at:new Date().toISOString()}:{}};let a=s.id;if(g||!a){const{data:d,error:N}=await v.from("inv_transactions").insert(m).select().single();if(N||!d)throw N??new Error("insert failed");a=d.id}else{const{error:d}=await v.from("inv_transactions").update(m).eq("id",a);if(d)throw d;await v.from("inv_transaction_items").delete().eq("transaction_id",a)}const u=b.filter(d=>d.item_id&&d.qty>0).map(d=>({transaction_id:a,line_no:d.line_no,item_id:d.item_id,qty:d.qty,unit:d.unit||null,notes:d.notes||null}));if(u.length){const{error:d}=await v.from("inv_transaction_items").insert(u).select().single();d&&console.warn(d)}return j({title:n(e?"wms.form.toast-posted":"wms.form.toast-saved")}),_(d=>({...d,id:a,status:e?"posted":"draft"})),a??null}catch(m){return console.error(m),j({title:n("wms.form.toast-error"),variant:"destructive"}),null}finally{I(!1)}},[s,b,l,g,v,n,j]),J=()=>{const e=a=>{const u=q.find(d=>d.id===a);return u?y==="ar"?u.name_ar:u.name_en||u.name_ar:null},c=new Map(z.map(a=>[a.id,a])),m=ie({title:n(A(l)),txn_no:s.txn_no,txn_date:s.txn_date,party_name:s.party_name,reference:s.reference,status:n(`wms.status.${s.status}`),notes:s.notes,from_warehouse:e(s.from_warehouse_id),to_warehouse:e(s.to_warehouse_id),recipient_name:f.recipient_name,recipient_title:f.recipient_title,recipient_empno:f.recipient_empno,receipt_time:f.receipt_time,is_delegated:f.is_delegated},b.filter(a=>a.item_id).map(a=>{const u=c.get(a.item_id);return{line_no:a.line_no,part_no:u?.part_no,qty:a.qty,unit:a.unit,notes:a.notes,description:u?(y==="ar"?u.name_ar:u.name_en)||u.description:"—"}}),{brand:n("wms.brand.name"),doc_no:n("wms.col.txn-no"),date:n("wms.col.date"),party:n("wms.col.party"),reference:n("wms.col.reference"),status:n("wms.col.status"),from:n("wms.form.from-wh"),to:n("wms.form.to-wh"),notes:n("wms.form.notes"),line:n("wms.col.line"),part_no:n("wms.col.part-no"),description:n("wms.col.name"),qty:n("wms.col.qty"),unit:n("wms.col.unit"),signature:n("wms.form.signature"),printed_at:n("wms.form.printed-at"),recipient_info:n("wms.form.recipient-info"),recipient_name:n("wms.form.recipient-name"),recipient_title:n("wms.form.recipient-title"),recipient_empno:n("wms.form.recipient-empno"),receipt_time:n("wms.form.receipt-time"),delegation:n("wms.form.delegation")},y);ne(m,`${n(A(l))} — ${s.txn_no}`)},U=l==="out"||l==="transfer"||l==="adjustment",G=l==="in"||l==="transfer"||l==="adjustment",K=h.useMemo(()=>`${n(A(l))} — ${g?n("wms.form.new"):s.txn_no}`,[l,g,s.txn_no,n]);return t.jsxs(ee,{title:K,subtitle:n(g?"wms.form.new-sub":"wms.form.edit-sub"),children:[t.jsxs("div",{className:"wms-form-grid",children:[t.jsx(w,{label:n("wms.col.txn-no"),children:t.jsx(x,{value:s.txn_no,onChange:e=>_({...s,txn_no:e.target.value})})}),t.jsx(w,{label:n("wms.col.date"),children:t.jsx(x,{type:"date",value:s.txn_date,onChange:e=>_({...s,txn_date:e.target.value})})}),t.jsx(w,{label:n("wms.col.reference"),children:t.jsx(x,{value:s.reference,onChange:e=>_({...s,reference:e.target.value})})}),l!=="transfer"&&t.jsx(w,{label:n("wms.col.party"),children:t.jsx(x,{value:s.party_name,onChange:e=>_({...s,party_name:e.target.value})})}),U&&t.jsx(w,{label:n("wms.form.from-wh"),children:t.jsxs(T,{value:s.from_warehouse_id??"",onChange:e=>_({...s,from_warehouse_id:e.target.value||null}),children:[t.jsx("option",{value:"",children:"—"}),q.map(e=>t.jsxs("option",{value:e.id,children:[e.code," · ",y==="ar"?e.name_ar:e.name_en||e.name_ar]},e.id))]})}),G&&t.jsx(w,{label:n("wms.form.to-wh"),children:t.jsxs(T,{value:s.to_warehouse_id??"",onChange:e=>_({...s,to_warehouse_id:e.target.value||null}),children:[t.jsx("option",{value:"",children:"—"}),q.map(e=>t.jsxs("option",{value:e.id,children:[e.code," · ",y==="ar"?e.name_ar:e.name_en||e.name_ar]},e.id))]})})]}),(l==="in"||l==="out")&&t.jsxs(t.Fragment,{children:[t.jsxs("div",{className:"wms-section",children:[t.jsxs("div",{className:"wms-section-title",children:["⚑ ",n("wms.form.delegation")]}),t.jsxs("label",{className:"wms-checkbox-row",children:[t.jsx("input",{type:"checkbox",checked:f.is_delegated,onChange:e=>$({...f,is_delegated:e.target.checked})}),n("wms.form.delegation")]})]}),t.jsxs("div",{className:"wms-section",children:[t.jsxs("div",{className:"wms-section-title",children:["▣ ",n("wms.form.recipient-info")]}),t.jsxs("div",{className:"wms-form-grid",style:{marginBottom:0},children:[t.jsx(w,{label:n("wms.form.recipient-name"),children:t.jsx(x,{value:f.recipient_name,onChange:e=>$({...f,recipient_name:e.target.value})})}),t.jsx(w,{label:n("wms.form.recipient-title"),children:t.jsx(x,{value:f.recipient_title,onChange:e=>$({...f,recipient_title:e.target.value})})}),t.jsx(w,{label:n("wms.form.recipient-empno"),children:t.jsx(x,{value:f.recipient_empno,onChange:e=>$({...f,recipient_empno:e.target.value})})}),t.jsx(w,{label:n("wms.form.receipt-time"),children:t.jsx(x,{type:"time",value:f.receipt_time,onChange:e=>$({...f,receipt_time:e.target.value})})})]})]})]}),t.jsxs("div",{className:"wms-lines-actions",children:[t.jsx("span",{className:"wms-lines-title",children:n("wms.form.lines")}),t.jsxs(C,{size:"sm",variant:"ghost",onClick:O,children:["+ ",n("wms.form.add-line")]})]}),t.jsx("div",{className:"wms-table-wrap",children:t.jsxs("table",{className:"wms-table is-edit",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{style:{width:50},children:n("wms.col.line")}),t.jsx("th",{children:n("wms.col.part-no")}),t.jsx("th",{style:{width:100},children:n("wms.col.qty")}),t.jsx("th",{style:{width:90},children:n("wms.col.unit")}),t.jsx("th",{children:n("wms.form.notes")}),t.jsx("th",{style:{width:40}})]})}),t.jsx("tbody",{children:b.map((e,c)=>t.jsxs("tr",{children:[t.jsx("td",{className:"wms-td-mono",children:e.line_no}),t.jsx("td",{children:t.jsxs(T,{value:e.item_id,onChange:m=>{const a=z.find(u=>u.id===m.target.value);S(c,{item_id:m.target.value,unit:a?.default_unit??e.unit})},children:[t.jsx("option",{value:"",children:"—"}),z.map(m=>t.jsx("option",{value:m.id,children:B(m)},m.id))]})}),t.jsx("td",{children:t.jsx(x,{type:"number",min:0,step:"any",value:e.qty,onChange:m=>S(c,{qty:Number(m.target.value)||0})})}),t.jsx("td",{children:t.jsx(x,{value:e.unit,onChange:m=>S(c,{unit:m.target.value})})}),t.jsx("td",{children:t.jsx(x,{value:e.notes,onChange:m=>S(c,{notes:m.target.value})})}),t.jsx("td",{children:t.jsx("button",{className:"wms-icon-btn",type:"button",onClick:()=>P(c),"aria-label":"delete",children:"×"})})]},c))})]})}),t.jsx("div",{className:"wms-form-grid",style:{marginTop:"1rem"},children:t.jsx("div",{style:{gridColumn:"1 / -1"},children:t.jsx(w,{label:n("wms.form.notes"),children:t.jsx(te,{value:s.notes,onChange:e=>_({...s,notes:e.target.value})})})})}),t.jsxs("div",{className:"wms-form-footer",children:[t.jsx(C,{variant:"ghost",onClick:()=>o(-1),children:n("wms.form.cancel")}),t.jsx(C,{variant:"ghost",onClick:J,children:n("wms.form.print")}),t.jsx(C,{variant:"ghost",disabled:D,onClick:()=>W(!1),children:n("wms.form.save-draft")}),t.jsx(C,{variant:"primary",disabled:D,onClick:async()=>{const e=await W(!0);e&&g&&o(`/wms/txn/${l}/${e}`,{replace:!0})},children:n("wms.form.post")})]})]})}export{fe as default};
